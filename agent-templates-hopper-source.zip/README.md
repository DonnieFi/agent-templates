# Agent Templates

Portable OpenClaw agents built around useful everyday jobs.

Each folder under templates/ is a standalone, independently versioned Template.
This source repository is separate from ClawHub publication: reviewing or merging
source does not publish a registry package or install an agent.

## Templates

### Hopper — Catch the right ride

[Hopper](templates/hopper/) helps a rider find stops and useful departures, check
direction and realtime freshness, and compare options using their walking time.
It does not require Home Assistant or continuous location tracking.

Status: initial draft. The candidate transit runtime has returned real Halifax
predictions in an isolated protocol test. Complete receiving-host Add and model
conversation proof, wider agency discovery, and background watches are unfinished.
See [verification](docs/VERIFICATION.md) and Hopper's README for exact boundaries.

## Layout

- templates/hopper/: Hopper's complete package source.
- templates/<another-agent>/: future independent packages.
- docs/VERIFICATION.md: observed evidence and outstanding checks.
- CONTRIBUTING.md: adding and changing packages.

## Validate one package

With a compatible OpenClaw CLI installed, run from this repository root:

    openclaw templates validate ./templates/hopper
    openclaw templates dev ./templates/hopper
    openclaw templates inspect ./templates/hopper

Build into an existing local output directory:

    mkdir -p dist
    openclaw templates build ./templates/hopper --out ./dist/hopper-0.1.0.tgz

These checks do not create an agent or publish a package. Add, connecting external
services, enabling automations, and ClawHub publication are separate reviewed
actions. Do not run installation or publishing commands as a test.

## Share a template

Keep source changes reviewable here, publish an explicitly reviewed package to
ClawHub, then share its link and useful examples in the
[OpenClaw Templates Showcase](https://community.openclaw.ai/t/openclaw-templates-showcase/415).
The showcase thread does not state a core-repository PR requirement.

Keep personal locations, real household records, credentials, local provider
installations, downloaded transit databases, and raw conversations out of this
repository. Example data must be clearly fictional; public feed observations
must be dated and not presented as current advice.
