# Contributing templates

Add a new agent under templates/<slug>/ with package.json, CLAW.md, README.md,
and first-run BOOTSTRAP.md when useful. Keep supporting files within that package.
Use OpenClaw's current manifest, not obsolete profiles/packages/cronJobs forms.

Describe input, job, output, and authority. Include a first useful conversation,
fictional examples, evidence requirements, and realistic acceptance scenarios.
Keep initial setup short and resumable. Do not ship actual user preferences.

For external tools, document supported setup, exact tested versions, operator
requirements, and missing capabilities. Do not promise automatic installation,
authentication, global coverage, or background work from a declaration alone.

Validate, inspect, and build the affected package with OpenClaw. Run helper tests
where applicable. Record real outcomes and untested layers in docs/VERIFICATION.md.
Review outgoing files for private data, credentials, and unsupported claims.

Open a scoped draft PR for unfinished work rather than describing it as ready.
Source review, GitHub merge, registry publication, and installing an agent are
four separate events; none should be claimed from another's receipt.
